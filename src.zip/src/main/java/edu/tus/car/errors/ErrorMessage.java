package edu.tus.car.errors;

public class ErrorMessage {
	String errorMessage;
	
	public ErrorMessage(String message) {
		this.errorMessage=message;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}

}
