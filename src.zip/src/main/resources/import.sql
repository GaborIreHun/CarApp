insert into "cars" ("make", "model", "year", "color")  values ('Mercedes','E220','2020','Black');
insert into "cars" ("make", "model", "year", "color")  values ('Volksvagen','Arteon','2021','Silver');
insert into "cars" ("make", "model", "year", "color")  values ('Audi','A6','2021','Red');
