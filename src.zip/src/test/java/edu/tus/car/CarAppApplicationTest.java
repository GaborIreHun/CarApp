package edu.tus.car;

import org.junit.jupiter.api.Test;

//Test class added ONLY to cover main() invocation not covered by application tests.
class CarAppApplicationTest {
	

	@Test
	void main() {
		CarAppApplication.main(new String[] {});
   }
}
